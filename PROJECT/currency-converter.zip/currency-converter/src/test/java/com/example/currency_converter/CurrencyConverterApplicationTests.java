package com.example.currency_converter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConverterApplicationTests {

	@Test
	void contextLoads() {
	}

}
