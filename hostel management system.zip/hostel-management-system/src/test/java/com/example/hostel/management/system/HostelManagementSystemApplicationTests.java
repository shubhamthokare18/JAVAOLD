package com.example.hostel.management.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HostelManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
