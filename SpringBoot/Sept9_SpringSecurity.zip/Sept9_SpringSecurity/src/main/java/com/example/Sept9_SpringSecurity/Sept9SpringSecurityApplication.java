package com.example.Sept9_SpringSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sept9SpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sept9SpringSecurityApplication.class, args);
	}

}
